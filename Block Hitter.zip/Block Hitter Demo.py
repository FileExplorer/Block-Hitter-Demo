'''
Full name: Yi Yang
Purpose: A minigame where the user throws a ball and tries to hit all the target boxes.
'''

import pygame
import random
import math
from drawable import *
from ball import *
from block import *
from text import *

#initializes pygame and sets the display and clock
pygame.init()
pygame.font.init()
screenDisplay = pygame.display.set_mode((400,400))
clock = pygame.time.Clock()

#List of targets for the player to shoot at
blockList = [
    Block(254,280,0),
    Block(274,280,0),
    Block(294,280,0),
    Block(254,260,0),
    Block(274,260,0),
    Block(294,260,0),
    Block(254,240,0),
    Block(274,240,0),
    Block(294,240,0),
]

#Collision calculations
def intersect(rect1, rect2):
    if (rect1.x < rect2.x + rect2.width) and (rect1.x + rect1.width > rect2.x) and (rect1.y < rect2.y + rect2.height) and (rect1.height + rect1.y > rect2.y):
        return True
    return False

#User interface and constants
dt = .1
g = 6.67
R = .7
eta = .5
xv = 0
yv = 0
count = 0
scoreText = Text("Score: 0", 20)
tutorialtexts = [
    Text('Welcome to Angry Balls Alpha Test!',20, 0, 320),
    Text('Your goal is to shoot down the rectangles using the circle.', 10, 0, 340),
    Text('Start aiming by holding down anywhere and dragging backwards.', 10, 0, 350),
    Text('BEWARE: dragging too far will lose the ball. No Ball = You Lose.',10, 0, 360)
]

running = True
Base = Line(0, 300)
userBall = Ball(50, 301)

#Runs pygame window and variables
while running:
    #draw objects
    clock.tick(144)
    screenDisplay.fill((255,255,255))
    Base.draw(screenDisplay)
    userBall.draw(screenDisplay)
    scoreText.draw(screenDisplay)

    for i in blockList:
        i.draw(screenDisplay)
        pygame.draw.rect(screenDisplay, (0, 0, 0), i.get_rect(), 1)

    for i in tutorialtexts:
        i.draw(screenDisplay)

    #pygame commands for what to do when a specific input is entered
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            pos1 = pygame.mouse.get_pos()
        elif event.type == pygame.MOUSEBUTTONUP:
            #distance calculation from when you hold to when you release the mouse
            pos2 = pygame.mouse.get_pos()
            xv = -(pos2[0] - pos1[0]) *.06
            yv = -(pos2[1] - pos1[1])

    #position and physics calculation for the ball after it is flung
    if abs(yv) > 0.0001:
        if (userBall.get_Loc()[1] > 300 and yv<0):
            yv = -R * yv
            xv = eta * xv
        else:
            yv = yv - (g * dt)
        userBall.set_Loc(userBall.get_Loc()[0] + xv, userBall.get_Loc()[1] - yv*dt)
    #Removes block from blockList when intersection of ball and rectangles are detected
    for i in blockList:
        if intersect(userBall.get_rect(), i.get_rect()):
            blockList.remove(i)
            count += 1
            scoreText.set_score("Score: %d" %count)
            scoreText.draw(screenDisplay)

    pygame.display.update()