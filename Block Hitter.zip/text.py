'''
Full name: Yi Yang
Purpose: Text class for drawing a words into pygame
'''


from drawable import *

class Text(Drawable):
    def __init__(self, message, size, x = 0, y = 0):
        super().__init__(x, y)
        self.__color = (0, 0, 0)
        self.__message = message
        self.__size = size
        self.__fontObj = pygame.font.Font("freesansbold.ttf", self.__size)

    def set_score(self, score):
        self.__message = score

    #draws the text
    def draw(self, surface):
        surface.blit(self.__fontObj.render(self.__message, True, self.__color), self.get_Loc())

    def get_rect(self, surface):
        pass