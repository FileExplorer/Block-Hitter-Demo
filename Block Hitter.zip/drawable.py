'''
Full name: Yi Yang
Purpose: Drawable class; the parent class all other object classes inherit to draw their shapes into pygame. Also a
class to draw a line into pygame.
'''

import pygame
import abc


class Drawable(metaclass = abc.ABCMeta):
    def __init__(self, x, y, visible = True):
        self.__x = x
        self.__y = y
        self.__visible = visible

    def getVisible(self):
        return self.__visible

    @abc.abstractmethod
    def draw(self, surface):
        pass

    def get_Loc(self):
        return self.__x, self.__y

    @abc.abstractmethod
    def get_rect(self, surface):
        pass

class Line(Drawable):
    def __init__(self, x, y):
        super().__init__(x, y)
        self.__color = (0, 0, 0)
    # draws the line

    def draw(self, surface):
        getLoc = self.get_Loc()
        pygame.draw.line(surface, self.__color, (getLoc[0], getLoc[1]), (getLoc[0] + 400, getLoc[1]))

    def get_rect(self, surface):
        pass
