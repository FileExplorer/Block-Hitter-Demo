'''
Full name: Yi Yang
Purpose: Ball class for drawing a circle into pygame
'''

from drawable import *


class Ball(Drawable):
    def __init__(self, x, y, visible = True):
        super().__init__(x, y)
        self.__color = (255, 0, 0)
        self.__radius = 5
        self.__x = x
        self.__y = y


    def get_Loc(self):
        return self.__x, self.__y

    #draws the circle
    def draw(self, surface):
        getLoc = self.get_Loc()
        pygame.draw.circle(surface, self.__color, (int(getLoc[0]), int(getLoc[1])), self.__radius)

    #gets the position of drewn circle for collision detection
    def get_rect(self):
        getLoc = self.get_Loc()
        return pygame.Rect(getLoc[0], getLoc[1], 5, 5)

    #allows ball to move when the position is changed
    def set_Loc(self, newX, newY):
        self.__x = newX
        self.__y = newY