'''
Full name: Yi Yang
Purpose: Block class for drawing a rectangle into pygame
'''

from drawable import *
import pygame


class Block(Drawable):
    def __init__(self, x, y, width):
        super().__init__(x, y)
        self.__color = (51, 162, 255)
        self.__width = width

    #draws the circle
    def draw(self, surface):
        getLoc = self.get_Loc()
        pygame.draw.rect(surface, self.__color, (getLoc[0], getLoc[1], 20, 20), self.__width)

    #gets the position of drewn rectangle for easy replication, creation of outline, and collision detection
    def get_rect(self):
        getLoc = self.get_Loc()
        return pygame.Rect(getLoc[0], getLoc[1], 20, 20)